// Import CSS first
import '../css/app.css';

// Then import JS dependencies
import './bootstrap';
import Alpine from 'alpinejs';

// Initialize Alpine.js
window.Alpine = Alpine;
Alpine.start();
